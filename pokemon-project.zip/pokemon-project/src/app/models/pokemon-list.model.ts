export interface PokemonListModel {
  count: number;
  next: string;
  previous: string;
  results: PokemonCharacteristic[];
}

export interface PokemonCharacteristic {
  name?: string;
  height?: number;
  weight?: number;
  imageUrl?: string;
  abilities?: { name: string; url?: string; }[];
  selected?: boolean;
}

export interface PokemonDetails {
  abilities: {
    ability: {
      name: string; url: string;
    }
  }[];
  height?: number;
  weight?: number;
  sprites?: {
    other: {
      'official-artwork': {
        front_default: string
      }
    }
  };
}
