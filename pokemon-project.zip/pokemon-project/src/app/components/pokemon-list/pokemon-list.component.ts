import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {PokemonCharacteristic, PokemonDetails, PokemonListModel} from '../../models/pokemon-list.model';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {NavigationEnd, Router} from '@angular/router';
import {filter} from 'rxjs/operators';
import {PokemonService} from '../../services/pokemon.service';

@Component({
  selector: 'app-pokemon-list',
  templateUrl: './pokemon-list.component.html',
  styleUrls: ['./pokemon-list.component.less']
})
export class PokemonListComponent implements OnInit {

  pokemonList: PokemonCharacteristic[] = [];
  filteredPokemonList: PokemonCharacteristic[] = [];
  pokemonListCopy: PokemonCharacteristic[] =[];
  control = new FormControl();
  selectedSortOption = '';
  searchString = '';
  selectedCardCount = 0;
  formGroup: FormGroup;
  pageCount = 1;

  private getPokeMonListUrl = 'https://pokeapi.co/api/v2/pokemon?offset=20&limit=20';
  private getPokemonDetailsUrl = 'https://pokeapi.co/api/v2/pokemon/{name}';
  private getNextPokemonListUrl = '';
  private getPreviousPokemonListUrl = '';
  constructor(private http: HttpClient, protected formBuilder: FormBuilder, private router: Router, private pokemonService: PokemonService) {

    this.router.events
      .pipe(filter((rs): rs is NavigationEnd => rs instanceof NavigationEnd))
      .subscribe(event => {
        if (
          event.id === 1 &&
          event.url === event.urlAfterRedirects
        ) {
          // code for page refresh
          this.searchString = localStorage.getItem('searchStr');
          this.selectedSortOption = localStorage.getItem('selectedSortOption');
        }
      });
  }

  ngOnInit() {
    this.formGroup = this.formBuilder.group({
      search: [null],
      sort: [null],
      total: [null]
    });
    this.formGroup.get('search').setValue(localStorage.getItem('searchString'));
    this.formGroup.get('sort').setValue(localStorage.getItem('selectedSortOption'));
    this.pokemonService.getPokemonList().subscribe((data: PokemonListModel) => {
      this.preparePokemonList(data);
    });
  }

  searchPokemon(searchString: string): void {
    if (searchString !== '') {
      localStorage.setItem('searchString', searchString);
      this.filterFunction(searchString);
    } else if (searchString === '') {
      this.filteredPokemonList = [];
      localStorage.removeItem('searchString');
    }
  }

  filterFunction(searchString: string): void {
    const pokemonListCopy = JSON.parse(JSON.stringify(this.pokemonList));
    this.filteredPokemonList = pokemonListCopy.filter((pokemon: PokemonCharacteristic) => {
      if (pokemon.name.includes(searchString)) {
        return pokemon;
      } else {
        pokemon.abilities.forEach((ability: {name: string; url: string;}) => {
          if (ability.name.includes(searchString)) {
            return pokemon;
          }
        });
      }
    });
  }

  sortList(sortOption: string): void {
    this.selectedSortOption = sortOption;
    if (this.filteredPokemonList.length) {
          const pokemonListCopy = JSON.parse(JSON.stringify(this.filteredPokemonList));
          this.pokemonListCopy = this.sortFunction(pokemonListCopy, sortOption);
        } else {
          const pokemonListCopy = JSON.parse(JSON.stringify(this.pokemonList));
          this.pokemonListCopy = this.sortFunction(pokemonListCopy, sortOption);
        }
    localStorage.setItem('selectedSortOption', sortOption);

  }

  sortFunction(sortArray: PokemonCharacteristic[], sortType: string): Array<PokemonCharacteristic> {

    switch (sortType) {

      case 'name': {
        const sortedArray = sortArray.sort((n1, n2) => {
          if (n1.name > n2.name) {
            return 1;
          }

          if (n1.name < n2.name) {
            return -1;
          }

          return 0;
        });
        return sortedArray;
      }
                   break;
      case 'height': {
        const sortedArray: PokemonCharacteristic[] = sortArray.sort((n1, n2) => n1.height - n2.height);
        return sortedArray;
      }
                     break;
      case 'weight': {
        const sortedArray: PokemonCharacteristic[] = sortArray.sort((n1, n2) => n1.weight - n2.weight);
        return sortedArray;
      }
    }
  }

  clearSort(): void {
    this.selectedSortOption = '';
    this.formGroup.get('sort').reset('');
    this.pokemonListCopy = [];
  }

  previousPage(): void {
    this.pageCount--;
    this.http.get(this.getPreviousPokemonListUrl).subscribe((data: PokemonListModel) => {
      this.preparePokemonList(data);
    });
  }

  nextPage(): void {
    this.pageCount++;
    this.http.get(this.getNextPokemonListUrl).subscribe((data: PokemonListModel) => {
      this.preparePokemonList(data);
    });
  }

  preparePokemonList(data: PokemonListModel): void {
    this.getNextPokemonListUrl = data.next;
    this.getPreviousPokemonListUrl = data.previous;
    this.pokemonList = data.results;
    this.pokemonList.forEach((pokemon: PokemonCharacteristic) => {
      this.pokemonService.getPokemonDetails(pokemon.name).subscribe((details: PokemonDetails) => {
        pokemon.height = details.height;
        pokemon.weight = details.weight;
        pokemon.imageUrl = details.sprites.other['official-artwork'].front_default;
        pokemon.abilities = [];
        pokemon.selected = false;
        details.abilities.forEach((ability: {ability: {name: string; url: string; }}) => {
          pokemon.abilities.push({
            name: ability.ability.name,
            url: ability.ability.url
          });
        });
      });
    });
  }

  selectCards(input: number): void {
    this.selectedCardCount = input;
    let count = 0;
    this.pokemonList.map((pokemon: PokemonCharacteristic) => {
      if (count !== input) {
        pokemon.selected = true;
        count ++;
      }
    });
  }

  clearCardSelection(): void {
    this.formGroup.get('total').reset('');
    this.pokemonList.map((pokemon: PokemonCharacteristic) => {
        pokemon.selected = false;
    });
    this.filteredPokemonList.map((pokemon: PokemonCharacteristic) => {
      pokemon.selected = false;
    });
    this.pokemonListCopy.map((pokemon: PokemonCharacteristic) => {
      pokemon.selected = false;
    });
  }
}
