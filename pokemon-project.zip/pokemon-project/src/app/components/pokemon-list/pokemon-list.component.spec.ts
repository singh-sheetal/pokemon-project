import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonListComponent } from './pokemon-list.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {PokemonService} from "../../services/pokemon.service";
import {of} from "rxjs";

describe('PokemonListComponent', () => {
  let component: PokemonListComponent;
  let fixture: ComponentFixture<PokemonListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        RouterTestingModule
      ],
      providers: [
        {
          provide: PokemonService,
          useClass: PokemonServiceStub
        },
      ],
      declarations: [ PokemonListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PokemonListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call preparePokemonList() on init method', () => {
    spyOn(component, 'preparePokemonList').and.callThrough();
    component.ngOnInit();
    expect(component.preparePokemonList).toHaveBeenCalled();
  });
});

export class PokemonServiceStub {
  getPokemonList() {
    return of({
      count: 1126,
      next: '',
      previous: '',
      results: [
        {
          name: 'Pikachu',
          height: 2,
          weight: 30,
          imageUrl: '',
          abilities: [
            {
              name: 'agile',
              url: ''
            }
          ]
        }
      ]
    });
  }

  getPokemonDetails() {
    return of({
      abilities: [
        {
          ability: {
            name: 'agile',
            url: 'https://pokeapi.co/api/v2/ability/25/'
          }
        }
      ],
      sprites: {
        other: {
          'official-artwork': {
            front_default: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/132.png'
          }
        }
      },
      height: 5,
      weight: 30
    });
  }
}
