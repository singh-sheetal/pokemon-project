import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {PokemonCharacteristic, PokemonDetails} from '../../models/pokemon-list.model';
import {HttpClient} from '@angular/common/http';
import {PokemonService} from '../../services/pokemon.service';

@Component({
  selector: 'app-pokemon-details',
  templateUrl: './pokemon-details.component.html',
  styleUrls: ['./pokemon-details.component.less']
})
export class PokemonDetailsComponent implements OnInit {
  pokemonDetails = {} as PokemonCharacteristic;
  private getPokemonDetailsUrl = 'https://pokeapi.co/api/v2/pokemon/{name}';
  private pokemonName = '';
  constructor(private activatedRoute: ActivatedRoute, private http: HttpClient, private router: Router, private pokemonService: PokemonService) { }

  ngOnInit() {
   this.pokemonName = this.activatedRoute.snapshot.paramMap.get('name');
   this.pokemonService.getPokemonDetails(this.pokemonName).subscribe((details: PokemonDetails) => {
        this.preparePokemonDetails(details);
    });
  }

  preparePokemonDetails(details: PokemonDetails): void {
    this.pokemonDetails.height = details.height;
    this.pokemonDetails.weight = details.weight;
    this.pokemonDetails.imageUrl = details.sprites.other['official-artwork'].front_default;
    this.pokemonDetails.abilities = [];
    details.abilities.forEach((ability: {ability: {name: string; url: string; }}) => {
      this.pokemonDetails.abilities.push({
        name: ability.ability.name,
        url: ability.ability.url
      });
    });
    console.log(this.pokemonDetails);
  }

  navigateToListView(): void {
    this.router.navigate(['/pokemons']);
  }
}
