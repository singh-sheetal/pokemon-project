import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {PokemonDetails, PokemonListModel} from '../models/pokemon-list.model';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PokemonService {
  private getPokeMonListUrl = 'https://pokeapi.co/api/v2/pokemon?offset=20&limit=20';
  private getPokemonDetailsUrl = 'https://pokeapi.co/api/v2/pokemon/{name}';
  constructor(private http: HttpClient) { }

  getPokemonList(): Observable<PokemonListModel> {
    return this.http.get<PokemonListModel>(this.getPokeMonListUrl);
  }

  getPokemonDetails(name: string): Observable<PokemonDetails> {
    return this.http.get<PokemonDetails>(this.getPokemonDetailsUrl.replace('{name}', name));
  }
}
