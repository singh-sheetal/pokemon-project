import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {PokemonDetailsComponent} from './components/pokemon-details/pokemon-details.component';
import {PokemonListComponent} from './components/pokemon-list/pokemon-list.component';


const routes: Routes = [
  {
    path: 'pokemons',
    component: PokemonListComponent
  },
  {
    path: 'pokemons/:name',
    component: PokemonDetailsComponent
  },
  {
    path: '',
    redirectTo: 'pokemons',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
