Unit Tests:

1. Run ng test only for pokemon-list component by commenting out the tests for pokemon-details component, a card for pokemon Pikachu should be shown in the Karma Chrome browser.

2. Run ng test for the whole application, details of pokemon Pikachu should be shown.

Not Completed Tasks:

1. Mobile and Tablet View
2. All combinations search string, sort and number of cards to be selected to filter the list is not properly tested.
